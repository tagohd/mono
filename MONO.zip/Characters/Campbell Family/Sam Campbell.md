---
alias: Sam, Sammich
Name: Sammich 'Sam' Campbell
Category: Main
Role: Damsel-in-distress (not a damsel and maybe not in distress)
DOB: 2002-10-22
Species: Dog (*Canis familiaris*)
Gender: "&quot;No, thanks!&quot; (they/them)"
Pronouns: they/them
Measurements:
  Height: 190.5
  Weight: 78.9
  Chest: 95
  Waist: 79
  Hips: 106
  Inseam: 92
Orientation: Queer (let's just leave it at that)
Personality: Athletic and outgoing.
MainGoal:
  - Not be captured by [[CURSED AL]], I guess?
  - They're just trying to get ready for college, man
Ability:
  STR: 15 (+2)
  DEX: 13 (+1)
  CON: 16 (+3)
  INT: 12 (+1)
  WIS: 10 (+0)
  CHA: 12 (+1)
References:
  - Cloth (Hollow Knight)???
  - Noelle Holiday (Deltarune)
  - Kronk (The Emperor's New Groove)
Notes:
SortOrder: 2
Focus: true
FocusComment: Do they have a SOUL or not? This may be determined by solving [[BFS 10000]].
---
Basically everything below is outdated. They're Luke's twin sibling now.
# Sam, THE INNOCENT ONE
Love interest for [Luke](Luke%20Campbell.md).

(Note 2023-05-21: I really haven’t written much about Sam. All that’s been decided so far is that they’re nonbinary, and their [[SOUL]] has been taken by [[CURSED AL]].)

[question:: What's their personality? Why does Luke like them?]

>[!question] Why did CURSED AL take their SOUL?
>Maybe they don't actually have a SOUL, and that's why they're important to CURSED AL's plan. (See: [[BFS 10000]]) So, he didn't just take their SOUL, he straight up kidnapped them.

question:: Do they have a SOUL or not?

[[4 - The Crossing of the First Threshold]]
>Perhaps it will be a recurring theme that Luke will find something that reminds him of Sam.
#Gameplay 
^reminders-of-sam
%%
vnViable:: Perhaps it will be a recurring theme that Luke will find something that reminds him of Sam. ([[Sam Campbell#^reminders-of-sam|ref]])

sudoChange:: New gameplay idea.
Priority:: 40

vnViable:: Scrapbook where Luke puts things he wants to show Sam. Or maybe there are opportunities to have your photo taken, like Earthbound. The player can choose not to do this, and it doesn't really affect anything. They just miss out on something cute/maybe you get an achievement if you get all of them. It might count as "ignoring what Luke wants to do", though. ([[Sam Campbell#^reminders-of-sam|ref]]) (Well, the scrapbook thing could work in a VN. Not sure about the other thing.)


Lun: Thats really cute...
%%

[question:: What are some things that would remind Luke of Sam?] And are they directly connected to Sam (i.e. something they actually owned), or is it just like, "These are Sam's favorite flowers"? Maybe Sam is also very fond of [[CURSED AL'S CURSED ORB|chocolate oranges]]?

# Characterizations

* They're about Luke's age, so... 16-17? (I haven't really decided how old Luke is, either.)
	[Lun]: Considering the significant amount of Luke-centered romance in this story, how about him being an adult? Like 20 or so?
	[Sudo]: Yeah, that can work. I went with Luke being 16 based off the scrapped idea that he turns into a dogboy instead of always being one, and he's such an idiot that he thinks it's Puberty 2: Electric Boogaloo. (Although, the older he is, the funnier that would be.)
	[Sudo]: Actually, I'm not sure if that can work, but I think I'll address that in [[Luke Campbell#Age|Luke's]] article instead.
* They're taller than [[Luke Campbell|Luke]]. In addition to being kind and dumb, Luke is also smol, so most people are taller than him, actually.
	[Lun]: We support short kings here
* Sam is based on a red fox (*Vulpes vulpes*), to the extent that that fits in the confines of the [[(5) May 2023 Chat Logs#Furites paradox|Furites paradox]]
* Do they *really* need saving from CURSED AL? Maybe they're more capable than Luke thinks.
	[Lun]: I feel like you would need to be VERY capable to escape from AL though, at least from how you've described him so far. Doesn't seem like a nice guy.
	[Sudo]: I think AL is built like a wizard. High INT, but low STR/CON. (Not that there aren't jacked wizards, but AL isn't one of them.) In a physical matchup, Sam has a clear upper hand.
	[Sudo]: That's not even getting into the fact that maybe his curse is that he's ~~French~~ trapped in the Astral Plane or something. If his physical body is still in the Material Plane, then it's completely defenseless. (Well, not completely, obviously. I'm sure he would make it very difficult to get to his body in the first place. But he wouldn't be physically fighting back once you did get there.)
* Or maybe (dun DUN DUNNN), getting captured was their plan all along!!! (Big maybe)
	[Lun]: I guess if you don't have a soul and some guy's plan is to load you with souls you could go along with it??
	[Sudo]: Lol 
* On the cross-country team with Luke, except they actually enjoy it
* Their lack of SOUL makes them a crucial component of CURSED AL's plan

![[tale_of_two_sams.png]]


>[!question] Is Sam short for "Samuel" or "Samantha"?
>Neither. It's short for "Sammich". (You'll never find out their AGAB or their deadname.)
>
>Actually, maybe they don't even have a deadname. Sammich is their actual birth name.

## Old Notes
- "Damsel in distress", but they're not a damsel, and whether they're in distress is also debatable
	- It'd be funny if they actually were in distress, but they're like, absolutely shredded.
	- They're already an absolute U N I T, but then you put them next to Luke, who is a smol bean, and they look even more massive
	- Like, you look at them next to CURSED AL, and it's clear they could easily just snap him in half, but they're completely unaware of this
		- I'm going to say that, depending on how many [[SOUL|souls]] CURSED AL currently possesses, a light breeze could knock him over
		- #Cite/Unknown [uRefType:: Character]
- Luke's neighbor/best friend/love interest
- Red fox
- Close in age to Luke

#character #sam-ward #unanswered-questions 