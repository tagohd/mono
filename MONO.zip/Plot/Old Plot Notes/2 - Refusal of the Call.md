[[Luke Campbell|Luke]] doesn’t want to be THE CHOSEN ONE. Why?

Luke’s just an ordinary guy. As much as he wants to find [[Sam Campbell|Sam]], he doesn’t know if he has what it takes to face [[CURSED AL]]. Of course, he eventually decides he has to try anyway because he loves Sam.

#general #act-1 #plot-outline #Character/Luke-Campbell #Character/Sam-Ward #Character/CURSED-AL 