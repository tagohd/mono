---
alias: Renaissance Faire, Renfest
---
Where the Renaissance Faire is hosted in early fall. [[Luke Campbell|Luke]] and [[Elizabeth Campbell|Elizabeth]] have gone every year since Luke was 8, but this is the first year [[Sam Campbell|Sam]] has been able to go. [[Ednathrallor Verdensmorder|Edna]] will also be making a surprise appearance. She's always wanted to go, but there's almost always a good gnome sale at the same time, and she can't pass that up.

Since he was 13, Luke has participated in the jousting tournament. He isn't very good.

#places #Plata/Ren-Faire #stub 