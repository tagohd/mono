Multiple protagonists, but they're really all the same person kind of. I don't know how well I can explain this right now, but kinda taking the whole "hero with a thousand faces" thing a bit more literally? And maybe it takes place across multiple epochs so we can sort of do the Chrono Trigger thing but not really. But maybe the idea is that it's cyclical. There's always going to be a [[CURSED AL]] and there's always going to be a [[Luke Campbell|Luke]] to stop him, even if they're not the same CURSED AL and Luke every time. (Or maybe it is the same CURSED AL but a different Luke? And CURSED AL is actually a metaphor for... something?) And also something something intergenerational trauma?

[Lun]: I still haven't played Chrono trigger...

You know, I haven't really put much thought into the story's themes. I guess I was never really planning to because it's ultimately more an avenue for my music than anything else, but I should try and figure out what the point is of the story I'm trying to tell because right now all I really have is "gay furries go brrr". And also Undertale. (Why did I say the same thing twice?) [question:: What am I trying to communicate with my story? If it was an actual game, what do I hope people would take away from it? What are the things that I hope people will write long rambling essays on Tumblr about?]

# What is MONO about?
(\^ Big question. Get it?)

Not what's the plot. What's it *about*?

I don't know if I can answer that yet...

[Lun]: Currently, it seems like some recurring themes are sacrifice and love? AL wants to sacrifice the universe to be with James, James want to sacrifice Luke to protect the universe, and Luke is kind of sacrificing himself to find Sam (though he might not see it in that way, or realize it at least). Also, friendship, of course. Oh, also, maybe solitude? A big motivation for AL is not wanting to live along (without James), the story starts of with Luke finding that Sam is missing, and most important of all it fits really well with the title: The greek word μόνος (monos) means "alone" after all
[Sudo]: That last one is an excellent point that I hadn't considered, but it's a very convenient coincidence.

## Themes according to [[(6) June 2023 Chat Logs]]
- The existence of fate, and the inevitability thereof
- Fucked up ideas of enlightenment
- Gay furries go brrr
- Wizard Divorce or: if two wizards were in the [[mana plane]] and one killed the other with a spell, would that be fucked up or what?

[Lun]: Don't forget about people being idiots!

# What else is important to me about MONO
## Representation
Already mentioned that everyone is queer, but now we also have... d i s a b i l i t i e s [question:: Why is anyone disabled in a universe where magic exists?]
  
- [[Luke Campbell|Luke]] is [[LukeVISION (TM)|colorblind]]
	- And an idiot. Is that a disability? [question:: Is idiot a disability?]
		[Lun]: If you want everyone to have a disability and this counts, you don't have any further work!
- Maybe [[CURSED AL|CURSED AL's]] curse is that he has ADHD/is ADHD-coded
- Maybe [[James Redawić|James]] is paraplegic or otherwise can't walk very far. (See: [[(Talk) James Redawić]])
	  [Lun]: Also works with what I suggested in [[CURSED AL#^fb3aaa]]!
- [[Sam Campbell|Sam]] has IBD (not to be confused with IED, IUD, or IBS)
	- They also don't have a [[SOUL]] [question:: Is "not having a SOUL" a disability? In this world, it could be.]

#general #Character/Luke-Campbell #Character/CURSED-AL  #unanswered-questions 